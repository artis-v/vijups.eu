from project_functions import impliciteuler, bdf2, quadraticroots
from numpy import *
import matplotlib.pyplot as plt

h_list = linspace(0.001,0.1,100)
loss_of_speed = []
for h in h_list:
    v_first, v_second = 0, 0
    u_list = [array([pi/2,0])]
    t = h
    first_step = True
    while t < 5 and v_second == 0:
        if first_step:
            u_list.append(impliciteuler(u_list[-1], h))
            first_step = False
        else:
            t += h
            u_list.append(bdf2(u_list[-2], u_list[-1], h))
            A = polyfit([t-2*h, t-h, t], [u_list[-3][0], u_list[-2][0], u_list[-1][0]], 2)
            V = polyfit([t-2*h, t-h, t], [u_list[-3][1], u_list[-2][1], u_list[-1][1]], 2)
            for T in quadraticroots(polyadd(A,pi/6)):
                if T >= t-h and T <= t:
                    t_obst = T
                    a_obst = polyval(A,t_obst)
                    v_obst = polyval(V,t_obst)
                    if v_first == 0:
                        v_first = v_obst
                    else:
                        v_second = v_obst
                    u_list[-1] = array([a_obst,v_obst])
                    u_list.append(array([a_obst,-v_obst]))
                    first_step = True
                    t = t_obst + h
                    break
    loss_of_speed.append(v_second-v_first)

plt.plot(h_list,loss_of_speed)
plt.yscale('function', functions=(lambda x: x**0.5, lambda x: x**2)) # quadratic y-axis
plt.ylim([0,max(loss_of_speed)])
plt.xlabel("h")
plt.ylabel("Difference (loss of speed)")
plt.title("Difference in first two reported velocities")
plt.savefig('plot.png', dpi=150)
print("Saved plot as plot.png.")