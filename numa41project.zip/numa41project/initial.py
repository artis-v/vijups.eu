from project_functions import impliciteuler, bdf2, phaseplot
from numpy import *

h = float(input("Input the step size: "))
u_list = [array([pi/2,0])]
t = h
first_step = True
while t < 20:
    if first_step:
        u_list.append(impliciteuler(u_list[-1], h))
        first_step = False
    else:
        t += h
        u_list.append(bdf2(u_list[-2], u_list[-1], h))

phaseplot(u_list, h, t)