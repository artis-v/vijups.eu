from project_functions import impliciteuler, bdf2, quadraticroots, phaseplot
from numpy import *

h = float(input("Input the step size: "))
u_list = [array([pi/2,0])]
t = h
first_step = True
while t < 5:
    if first_step:
        u_list.append(impliciteuler(u_list[-1], h))
        first_step = False
    else:
        t += h
        u_list.append(bdf2(u_list[-2], u_list[-1], h))
        A = polyfit([t-2*h, t-h, t], [u_list[-3][0], u_list[-2][0], u_list[-1][0]], 2)
        V = polyfit([t-2*h, t-h, t], [u_list[-3][1], u_list[-2][1], u_list[-1][1]], 2)
        for T in quadraticroots(polyadd(A,pi/6)):
            if T >= t-h and T <= t:
                t_obst = T
                a_obst = polyval(A,t_obst)
                v_obst = polyval(V,t_obst)
                print(f"Hit! t={t:.15f}, a={a_obst:.15f}, v={v_obst:.15f}.")
                u_list[-1] = array([a_obst,v_obst])
                u_list.append(array([a_obst,-v_obst]))
                first_step = True
                t = t_obst + h
                break

phaseplot(u_list, h, t, "obstacle")