from numpy import *
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.cm import ScalarMappable

def newton(F, u, tol=1e-12, e=0.001):
    """Newton iteration using the symmetric difference quotient
    Args:
        F: function
        u: initial value
        tol: tolerance, defaults to 1e-12
        e: quotient epsilon, defaults to 0.001
    Returns:
        result of Newton iteration
    """    
    dF = lambda u: (F(u + e) - F(u - e)) / (2 * e)
    while True:
        u_prev = u
        u = u - F(u) / dF(u)
        if linalg.norm(u - u_prev, ord = 2) < tol:
            return u

def impliciteuler(u1, h):
    """One step of Euler's implicit method
    Args:
        u1: the previous vector
        h: step size
    Returns:
        u: the next vector
    """    
    f = lambda u: array([u[1], -9.81*sin(u[0])])
    F = lambda u: u - u1 - h * f(u)
    u = newton(F, u1)
    return u

def bdf2(u2, u1, h):
    """One step of the BDF-2 method
    Args:
        u2: the second-to-last vector
        u1: the previous vector
        h: step size
    Returns:
        u: the next vector
    """    
    f = lambda u: array([u[1], -9.81*sin(u[0])])
    F = lambda u: u - 4/3 * u1 + 1/3 * u2 - h * 2/3 * f(u)
    u = newton(F, u1)
    return u

def quadraticroots(p):
    """Find real roots of a quadratic polynomial
    Args:
        p: quadratic polynomial
    Returns:
        list of real roots
    """  
    a, b, c = p
    D = b**2 - 4*a*c
    if D < 0:
        return []
    else:
        return [(-b + sqrt(D)) / (2*a), 
                (-b - sqrt(D)) / (2*a)]
    
def make_segments(x, y):
    '''
    Create list of line segments from x and y coordinates, in the correct format for LineCollection:
    an array of the form   numlines x (points per line) x 2 (x and y) array
    '''
    # Initially added from https://nbviewer.org/github/dpsanders/matplotlib-examples/blob/master/colorline.ipynb
    points = array([x, y]).T.reshape(-1, 1, 2)
    segments = concatenate([points[:-1], points[1:]], axis=1)
    return segments

def colorline(x, y, z=None, cmap=plt.get_cmap('gist_rainbow'), norm=plt.Normalize(0, 1), linewidth=3, alpha=1.0):
    '''
    Plot a colored line with coordinates x and y
    Optionally specify colors in the array z
    Optionally specify a colormap, a norm function and a line width
    '''
    # Initially added from https://nbviewer.org/github/dpsanders/matplotlib-examples/blob/master/colorline.ipynb
    # Default colors equally spaced on [0,1]:
    if z is None:
        z = linspace(0, 1, len(x))
    # Special case if a single number:
    if not hasattr(z, "__iter__"):  # to check for numerical input -- this is a hack
        z = array([z])
    z = asarray(z)
    segments = make_segments(x, y)
    lc = LineCollection(segments, array=z, cmap=cmap, norm=norm, linewidth=linewidth, alpha=alpha)
    ax = plt.gca()
    ax.add_collection(lc)
    return lc

def phaseplot(u_list, h, t, scenario="initial"):
    """Phase plot for the given data
    Args:
        u_list: list of vectors
        h: step size
        t: time value for the final vector
        scenario: name of the scenario, defaults to "initial"
    """    
    a_list = [u[0] for u in u_list]
    v_list = [u[1] for u in u_list]
    plt.figure(figsize=(8,5))
    plt.xlim([-1.75,1.75])
    plt.ylim([-4.5,4.5])
    colorline(a_list,v_list,linewidth=1)
    plt.title(rf"Phase plot of pendulum, {scenario} scenario, step size h={h}")
    plt.xlabel(r"Position $\alpha$")
    plt.ylabel(r"Velocity $v$")
    cbar = plt.colorbar(ScalarMappable(norm=plt.Normalize(0,t), cmap='gist_rainbow'), label=r"Time $t$")
    cbar.ax.invert_yaxis()
    plt.savefig('plot.png', dpi=150)
    print("Saved plot as plot.png.")